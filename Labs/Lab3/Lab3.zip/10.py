wavelength = int(input("What is your wavelength in nm: "))

if wavelength >= 620 and wavelength <750:
    print("The color is red")
elif wavelength >= 380 and wavelength <450:
    print("The color is violet")   
elif wavelength >= 450 and wavelength <495:
    print("The color is blue") 
elif wavelength >= 495 and wavelength <570:
    print("The color is green") 
elif wavelength >= 570 and wavelength <590:
    print("The coloris yellow") 
elif wavelength >= 590 and wavelength <620:
    print("The color is orange") 

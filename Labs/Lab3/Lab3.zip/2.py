num = int(input("Enter your number: "))

if num%2 ==0 :
    print(f"Your number {num} is even ")
else :
    print(f"Your number {num} is odd.")    
personal = int(input("Enter your letters: "))

if len(personal) == 3:
    print("You are elligible for old license plate")
elif len(personal) ==4:
        print("You are elligible for new license plate")
else:
    print("Invalid number")        


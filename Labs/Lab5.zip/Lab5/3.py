myList.append("apple")
myList.append(76)
myList.insert(2, "cat")

myList.insert(0, 99)
hello_index = myList.index("hello")
count_76 = myList.count(76)
myList.remove(76)

true_index = myList.index(True)
myList.pop(true_index)
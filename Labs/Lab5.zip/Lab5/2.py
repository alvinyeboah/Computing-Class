def sum_of_squares(xs):
    result = 0
    for x in xs:
        result += x ** 2
    return result
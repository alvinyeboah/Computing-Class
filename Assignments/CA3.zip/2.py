def expon(base,exponent):
    result = base ** exponent
    print(f"The result of {base} to the power {exponent} is {result} ")

expon(5,2)    
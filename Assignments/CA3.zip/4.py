def num_counter(digit):
    lenght = len(str(digit))
    print(f" Your number {digit} has {lenght} digits")

num_counter(7678812242)    
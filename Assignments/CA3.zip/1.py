def greeting(name, age):
    print(f"Hello, my name is {name} and my age is {age}")

greeting("Alvin", 12)  

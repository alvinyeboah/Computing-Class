import math as m

def pytha_theorem(a, b):
    c = m.sqrt((a**2)+ (b**2))
    print(f"The length of the hypotenuse is {c}")


pytha_theorem(6,7)    
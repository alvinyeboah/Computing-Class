def convertor(celsius):
    Fahrenheit = (9/5) * celsius +32.
    print(f"Your temperature in fahrenheit is {Fahrenheit}")

convertor(2)    
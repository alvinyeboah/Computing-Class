import math
r = 2.5
h = 4
cone_volume = (1/3) * math.pi * r**2 * h
print(f"The volume of the cone is {cone_volume}")
total_chocolate = 213
students_semester2 = 133
chocolate_per_student = total_chocolate // students_semester2
remaining_chocolates = total_chocolate % students_semester2
print(f"Each student gets {chocolate_per_student}  and there  are {remaining_chocolates} remaining.")
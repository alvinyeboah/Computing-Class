import math
height = float(input("Enter the height of your tank"))
radius = float(input("Enter the radius of your tank"))
volume = math.pi * radius**2 * height
print(f"The volume is{volume}")
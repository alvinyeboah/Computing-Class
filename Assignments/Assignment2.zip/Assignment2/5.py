months = int(input("What is the age in months?"))
years = months // 12
remaining_months = months % 12
print(f"The baby is {years} ,{remaining_months} months.")
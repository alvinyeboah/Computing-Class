students_semester1 = 62
students_semester2 = 133
percent_increase = ((students_semester2 - students_semester1) / students_semester1) * 100
print(f"There was a {percent_increase}% increase.")

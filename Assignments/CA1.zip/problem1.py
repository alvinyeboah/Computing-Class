# Problem decompositin
# Action Verbs
# Accepts input
# Convert Input into seconds


user_minutes = int(input("Enter your number in  minutes:"))
user_seconds = int(input("Enter your number in seconds:"))

result = (user_minutes *60) +(user_seconds)

print("The final answer is "+str(result)+ " seconds")
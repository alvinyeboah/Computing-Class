n = int(input("What is your positive integer?"))

sum = ((n)*(n+1))//2

print(
    f"The sum of all positive integers from 1 to {n} is {sum}")

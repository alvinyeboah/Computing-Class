width = int(input("Enter the width of your room:"))
length = int(input("Enter the length of your room:"))

area = length* width
print(f"The area of your room is {area}")
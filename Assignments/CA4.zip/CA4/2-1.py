import csv

Country_name=[]
Population=[]
Literacy_rate=[]
mobile_subscriptions=[]
internet_users=[]
production =[]
consumption =[]
dict1= {}
count = 0


with open("/Users/alvinyeboah/Documents/Uni/Computing/Assignments/CA4/CountryData.csv", 'r') as file:
    csv_reader = csv.reader(file)
    next(csv_reader, None)
    for column in csv_reader:
        count = 0
        count += 1
        Country_name.append(column[0])
        Population.append(column[0])
        Literacy_rate.append(column[0])
        mobile_subscriptions.append(column[0])
        internet_users.append(column[0])
        production.append(column[0])
        consumption.append(column[0])
        dict1[column[0]] = dict1.get(column[0], 0) + 1
print(dict1)
        
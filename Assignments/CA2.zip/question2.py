import time

current = time.asctime()
print(current)
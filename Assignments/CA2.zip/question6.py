a = int(input("Enter your first integer"))
b = int(input("Enter your second integer"))

added = a+b
difference = a-b
product = a*b
quotient = a//b
remainder= a%b
power = a**b


print(f"The sum of a and b is {added}")
print(f"The difference when b is subtracted from a is {difference}")
print(f"The product of a and b is {product}")
print(f"The quotient when a is divided by b is {quotient}")
print(f"The remainder when a is divided by b  is {remainder}")
print(f"The result of a raised to the power b is {power}")
